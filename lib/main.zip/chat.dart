import 'dart:math';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:savera/mesh.dart';
import 'package:savera/user_config.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  final TextEditingController _messageController = TextEditingController();
  final List<String> _messages = [];
  late TabController _tabController;

  final List<Map<String, dynamic>> _liveSOS = [];
  final List<Map<String, dynamic>> _ackSOS = [];
  final List<Map<String, dynamic>> _chats = [];
  String? _myUserName;
  String? _myRole;

  final TextEditingController _chatController = TextEditingController();

  @override
  // void initState() {
  //   super.initState();
  //   _tabController = TabController(length: 2, vsync: this);
  // }
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    UserConfig.getUserName().then((name) {
      setState(() => _myUserName = name);
    });
    UserConfig.getRole().then((role) {
      setState(() => _myRole = role);
    });

    initMesh();
  }

  Future<void> initMesh() async {
    final statuses = await [
      Permission.location,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.nearbyWifiDevices,
    ].request();

    if (statuses.values.every((s) => s.isGranted)) {
      await Mesh.init();
    } else {
      debugPrint("❌ Missing required permissions for mesh networking");
    }
  }

  void _sendChat() {
    final text = _chatController.text.trim();
    if (text.isEmpty) return;

    final msg = {
      "id": Random().nextInt(1 << 31).toString(),
      "type": "chat",
      "fromRole": _myRole ?? "helper",
      "userName": _myUserName, // TODO: load from UserConfig
      "msg": text,
      "timestamp": DateTime.now().toIso8601String(),
    };

    Mesh.sendStructured(msg);
    setState(() => _chats.add(msg));
    _chatController.clear();
  }

  String _formatTime(String? isoTime) {
    if (isoTime == null) return "";
    try {
      final dt = DateTime.parse(isoTime);
      return DateFormat("dd MMM yyyy, h:mm a").format(dt);
    } catch (_) {
      return isoTime;
    }
  }

  Widget _buildChatTile3(Map<String, dynamic> m, String? myUserName) {
    final role = m['fromRole'] ?? 'peer';
    final name = m['userName'] ?? role;

    final isMe = (myUserName != null && name == myUserName);
    debugPrint("isMe: $isMe, name: $name, myUserName: $myUserName");

    // return Align(
    //   alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
    //   // ... rest of bubble UI ...
    // );
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 280),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isMe ? Colors.green[200] : Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(12),
              topRight: const Radius.circular(12),
              bottomLeft: isMe
                  ? const Radius.circular(12)
                  : const Radius.circular(0),
              bottomRight: isMe
                  ? const Radius.circular(0)
                  : const Radius.circular(12),
            ),
            boxShadow: const [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 2,
                offset: Offset(1, 1),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: isMe
                ? CrossAxisAlignment.end
                : CrossAxisAlignment.start,
            children: [
              if (!isMe) // only show sender for others
                Text(
                  "$name ($role)",
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              Text(
                m['msg']?.toString() ?? '',
                style: const TextStyle(fontSize: 15),
              ),
              const SizedBox(height: 4),
              Text(
                _formatTime(m['timestamp']),
                style: const TextStyle(fontSize: 10, color: Colors.black54),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Chat"),
        // bottom: TabBar(
        //   controller: _tabController,
        //   tabs: const [
        //     Tab(text: "Messages"),
        //     Tab(text: "Send Message"),
        //   ],
        // ),
      ),
      // body: Column(
      //   children: [
      //     Column(
      //       children: [
      //         // Expanded(
      //         //   child: ListView(
      //         //     padding: const EdgeInsets.all(8),
      //         //     children: _chats.map((m) => _buildChatTile2(m)).toList(),
      //         //   ),
      //         // ),
      //         Expanded(
      //           child: FutureBuilder<String?>(
      //             future: UserConfig.getUserName(),
      //             builder: (context, snapshot) {
      //               if (!snapshot.hasData) {
      //                 return const Center(child: CircularProgressIndicator());
      //               }
      //               final myUserName = snapshot.data;

      //               return ListView(
      //                 padding: const EdgeInsets.all(8),
      //                 children: _chats
      //                     .map((m) => _buildChatTile3(m, myUserName))
      //                     .toList(),
      //               );
      //             },
      //           ),
      //         ),

      //         Padding(
      //           padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      //           child: Row(
      //             children: [
      //               Expanded(
      //                 child: TextField(
      //                   controller: _chatController,
      //                   decoration: const InputDecoration(
      //                     hintText: "Enter message",
      //                   ),
      //                 ),
      //               ),
      //               IconButton(
      //                 icon: const Icon(Icons.send),
      //                 onPressed: _sendChat,
      //               ),
      //             ],
      //           ),
      //         ),
      //       ],
      //     ),
      //   ],
      // ),
      body: Column(
        children: [
          Expanded(
            child: FutureBuilder<String?>(
              future: UserConfig.getUserName(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final myUserName = snapshot.data;
                return ListView(
                  padding: const EdgeInsets.all(8),
                  children: _chats
                      .map((m) => _buildChatTile3(m, myUserName))
                      .toList(),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _chatController,
                    decoration: const InputDecoration(
                      hintText: "Enter message",
                    ),
                  ),
                ),
                IconButton(icon: const Icon(Icons.send), onPressed: _sendChat),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
